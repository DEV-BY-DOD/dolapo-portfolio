Create a one-page developer portfolio website as public/index.html.

My details:
- Name: Oludolapo Olowe
- Tagline: [Computing student at UEL, into AI and building things"]
- About: [I am a Data sicence and artificial intelligence student at the University of East london, i am orginally from nigeria and in the uk studying my first degree.]  
- Skills: [Basic HTML/CSS ,Basic java, Communication Skills.]
- Projects:
  1. [Website] — [DEV BY DOD - Its a functioning website that enables people to book web development services ]
  2. [Website] — [Shopping by d- its a functioning e- commerce website that enables people to shop trendy clothing]
  3. [Website] — [Curated by d- its an AI gallery expressing the creativity of aritifical intelligence]
- Links: GitHub [Dolapo-Olowe], LinkedIn [Dolapo Olowe], Email [dolapoolowe2@gmail.com]

Design:
- Theme: [a deep purple fusion with a unique touch of cream and black, make it clean and unique, make different tabs and make it futursitic]
- Sections: hero, about, skills, projects, contact
- One self-contained HTML file — no frameworks, no build step, no external dependencies
- Modern, clean, professional, with a nice accent colour